<?php
    include('security.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NUS Consulting Group | Parent Company List</title>
    <link rel="icon" href="img/social-square-n-blue.png">
      <link
      rel="stylesheet"
      href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"
    />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link
      rel="stylesheet"
      href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css"
    />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet"/>
    <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

    <style>
        .dropdown-menu {
            position: absolute;
            top: -4%;
            left: -151px;
        }
        #DataTables_Table_0_wrapper {
            position: absolute;
            width: 87%;
            margin: 80px 0 0 360px;
        }

       #myTable_wrapper {
            position: absolute;
            width: 76%;
            left: 20%;
           /* margin: 0px 0 0 300px;*/
        }

      
        table {
            border: 2px solid #D2DDEC;
            border-radius: 6px;
            /*width: 76%;
            margin: 10px 300px;*/
            /* height: 70vh; */
        }
        /* table.dataTable thead > tr > th.sorting_asc::before {
            opacity: 1;
            position: absolute;
            left: 13%;
            color: black;
        }
        table.dataTable thead > tr > th.sorting::after {
            opacity: 1;
            position: absolute;
            left: 13%;
            color: black;
        } */
        table th {
            color: #343a40;
            background: #F9FBFD;
        }
        table.myTable thead th {
            border-bottom: 1px solid #CED4DA !important;
        }
        table td {
            color: #12263f;
            font-size: 13px;
            border-bottom: 1px solid #CED4DA;
            text-transform: capitalize;
        }
        table.dataTable.no-footer {
            /* border-bottom: 2px solid #D2DDEC !important; */
            border-bottom: none !important;
        }

        table tbody td a {
            color: #12263f;
            text-decoration: none;
            font-size: 14px;
            /* text-transform: capitalize; */
        }

        table tbody td a:hover {
            text-decoration: none;
            color: #12263f;
        }

        .parentdatas{
            text-decoration: none;
        }
        .parent {
            text-align:left;
        }
        .clientfrs {
            margin: 40px 0 0 20%;
            position: relative;
            top: 8%;
            font-weight: 600;
            font-size: 20px;
        }
        .padmd0{
             width: 76%;
            margin: 10px 300px;
        }
        table.dataTable thead > tr > th.sorting_asc::before, 
        table.dataTable thead > tr > th.sorting_desc::after {
            opacity: 1;
        }
        td {
            background: white;
        }
        .clientfrs, .clientfrs:hover {
            margin: 40px 0 0 20%;
            position: relative;
            top: 8%;
            font-weight: 600;
            font-size: 20px;
            color: gray;
            text-decoration: none;
        }
        .clientss, .clientss:hover {
            position: relative;
            text-decoration: none;
            top: 8%;
            font-weight: 600;
            font-size: 20px;
            color: #345DA6;
            text-decoration: none;
        }
        .views, .views:hover {
            color: #fff;
            background-color: #345DA6;
            border-color: #345DA6;
            padding: 5px 10px;
            border-radius: 25px;
        }
    </style>
</head>
<body>
<div class="main">
        <div class="menu">

            <?php
                include('sidebar.php');
            ?>
        </div>
    <div>
        <br>
        <br>
   <p><a href="clientcompany.php?id=<?=$_GET['parent']?>" class="clientfrs" ><?=$_GET['parent']?> > </a><a href="" class="clientss"><?=$_GET['clinet']?></a></p>
<div class="padmd0">
                <?php
              if(isset($_SESSION['deleted'])&&((time() - $_SESSION['deleted']) < 2)) {
                
                echo '<script> toastr.error("Deleted", "New Supply contract ");</script>';
                if((time() - $_SESSION['deleted']) > 2){
                    unset($_SESSION['deleted']);
                }
              } 
              
             ?>  
        <table class="myTable" id="myTable">
        <thead class="">
            <!-- <tr> -->
            <th class="">Country</th>
            <th class="">Commodity</th>
            <th class="">Contract Name</th>
            <th class="">Supplier Name</th>
            
            <th class="">Contract Start</th>
            <th class="">Contract End</th>
            <th class="">Status</th>
           
            <th class="">Contract Type</th>
            <th class="">Annual Consumption</th>
            <!-- <th class=""></th> -->
            <th class=""></th>
            <!-- </tr> -->
        </thead>
        <tbody>
        <?php
                include('dbconn.php');

    include 'includes/functions.php';
    $functions = new libFunc();
      
                $user = $_GET['id'];
                $sql = "SELECT * FROM nus_supply_contract WHERE clientId='$user' ORDER BY supplierId DESC";
                $result = mysqli_query($conn,$sql);

                while($row = mysqli_fetch_assoc($result)) {
        ?>
            
                <tr>       
                    
                        <?php
                        $prve = 'preview';
                        if($_SESSION['role'] == 'Admin' || $_SESSION['role'] == 'NUS Manager' || $_SESSION['role'] == 'NUS User'){
                            $prve ='edit';
                        }
                        ?>
                    <td><?= $row['countryName']; ?></td>
                    <td><?= $row['commodityName']; ?></td>
                    <td><a href="supplycontractpreview.php?id=<?=$row['supplierId']?>&type=preview&role=<?=base64_encode('role')?>"><?= $row['contract_id']; ?></a></td>
                    <td style="color: #345DA6;"><?= $row['supplyName'];?></td>
                    
                    
                    <td><?= date('d-M-Y',strtotime($row['contractTermfromDate'])); ?></td>
                    <td><?= date('d-M-Y',strtotime($row['contractTermtoDate'])) ?></td>
                    <td><?php 
                    
                    $expire = strtotime($row['contractTermtoDate']);
                    $today = strtotime("today midnight");
                    if($today >= $expire){
                        echo "<span style='background: #ffe9dc; color: #eb2808;padding: 5px 15px;border-radius: 3px;font-weight: 500;'>Expired</span>";
                    } else {
                        echo "<span style='background: #DCFFF0; color: #026A3E;padding: 5px 15px;border-radius: 3px;font-weight: 500;'>Live</span>";
                    }
                    ?></td>
                  
                    <td><?= $row['contractType']; ?></td>
                    <td><?=$row['totalAnualConsumption'];?></td>
                    <td><div class="btn-group">
                    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" style="background: #345DA6;">
                     <i class="fa fa-ellipsis-v" aria-hidden="true"></i></button>
                    <ul class="dropdown-menu" role="menu">


                      <li><a href="supplycontractpreview.php?id=<?=$row['supplierId']?>&type=preview&role=<?=base64_encode('role')?>">Preview</a></li>
                      <?php
                        if($_SESSION['role'] == 'Admin' || $_SESSION['role'] == 'NUS Manager' || $_SESSION['role'] == 'NUS User') {
                        ?>
                      
                      <li><a href="supplycontractpreview.php?id=<?=$row['supplierId']?>&type=edit">Edit</a></li>

                     
                      <?php
                  }

                      ?>
                    </ul>
                  </div></td>
                </tr>
            <?php }?>
           
        </tbody>
    </table>

</div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" ></script>
    <script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js">
    </script>
    <script>
        $(document).ready( function () {
         $('#myTable').DataTable();
        } );
        function deletecontract(id, cType){
            let text = "Are want to Archive this contract";
            alert(text);
            // if (confirm(text) === true) {

            //      $.ajax({
            //       type:'POST',
            //       url: 'js/callbacks/deletesupplycontract.php',
            //       data:{
            //         'supplierid':id,
            //         'contracttype':cType
                  
            //       },
            //       success: function(data){
            //       window.location.href = window.location.href;
            //       }
            //     });
               
            // } 
        }
    </script>
    <?php
        include('hoverinclude/hoverhome.php');
    ?>
    </body>
</html>
