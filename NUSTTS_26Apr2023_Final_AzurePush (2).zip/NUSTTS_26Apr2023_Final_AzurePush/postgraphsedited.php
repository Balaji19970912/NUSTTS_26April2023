<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NUS FRS System | Generate Report</title>
    <link rel="icon" href="img/social-square-n-blue.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type = "text/javascript">
         google.charts.load('current', {packages: ['corechart']});     
      </script>
    <link rel="stylesheet" type="text/css" href="css/postgraph.css">
    <style>
      

        .nusLogo {
            margin: 0 0 0 15px;
        }
        
     
        
        .back{
            border: 1px solid #345da6;
            padding: 8px 25px;
            background-color: #345da6;
            position: absolute;
            right: 35%;
            top: 8.6%;
            color: white;
            text-decoration: none;
            border-radius: 5px;

        }
        .printPDF {
            border: 1px solid #345da6;
            padding: 8px 25px;
            background-color: #345da6;
            position: absolute;
            right: 17.2%;
            top: 8.6%;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        button {
            position: absolute;
            right: 24.5%;
            top: 8.6%;
            border: 1px solid #345da6;
            padding: 10px 18px;
            background-color: #345da6;
            color: white;
            border-radius: 5px;
        }

         /* Button hover for Export */
         .btnExport {
            background-color: #345da6;
            color: white;
            padding: 10px;
            border: none;
        }

      
    /* button hover ends */

        table {
            border-collapse: collapse;
            
        }

        table th {
            text-align: right;
            padding:5px;
        }
        table td {
            padding:5px;
        }
        .hrline {
           border-top: 1px solid grey;
        }
        .hrlines {
           border-bottom: 1px solid grey;
        }
        .line{
            border-top: 1px solid grey;
            border-bottom: 1px solid grey;
        }

        #tableDataColor {
            color: blue;
        }

        /*Print css starts */

        @media print {
            .sec1art1Wrapper li span {
                font-size: 0.6em;
            }
            .sec1art1Wrapper  li h2 {
                font-size: 10pt;
            }
            #printbtn {
                display: none;
            }
            #top_x_div {
                margin: 20pt 0 0 0;
            }
        }
         /*Print css ends */
    </style>
</head>
<body>
    <header>
        <div class="headerWrapper">
            <img src="img/nus-logo-2020.svg" alt="NUS Logo" class="nusLogo">
            <a href="" class="back">Back</a>
            <a href="" class="printPDF">Print</a>

            <!-- <button onclick='window.history.go(-1);' id ="printbtn">Back</button>
            <button class="pdfBtn" id="printbtn" onclick="windows.print()">Print PDF</button> -->
            <button class="excelBtn" id="printbtn">Export to Excel</button 
        </div>
    </header>
    <?php
        include('dbconn.php');
        error_reporting(E_ERROR | E_PARSE);
        include 'includes/functions.php';
        $functions = new libFunc();
        // echo $_POST['contractId'];
        $supplier =  $functions->getsuppliedId($_POST['contractIds']);

        

        $tradeper = '';
        foreach ($_POST['yearstype'] as $key => $value) {
            $tradeper = $value;
        }

        $contract_query = "SELECT basegenconsumption,effectcon FROM nus_supply_contract WHERE supplierId = '".$supplier."'";
        $contract_qry = mysqli_query($conn, $contract_query);
        $consumptions = '';
        $eff = '';
        while ($contract_row = mysqli_fetch_assoc($contract_qry)) {
            $consumptions = $contract_row['basegenconsumption'];
            $eff = $contract_row['effectcon'];
        }
        $toarraycon = explode('|', $consumptions);
        $toeff =  explode('|', $eff);
        $alvalues = explode(',', $_POST['allgenmonth']);
        $baseconsu = array();
        $effectcons = array();
        foreach ($toarraycon as $key => $vavalue) {
            $explode = explode('-', $vavalue);
            if(in_array($explode[0], $alvalues) && $explode[1]== $tradeper){
                if(isset($_POST['basload'.$explode[0].$explode[1]])){
                    $baseconsu[] = $explode[0].'-'.$explode[1].'-'.$_POST['basload'.$explode[0].$explode[1]];
                }
                
            }else{
                 $baseconsu[] = $explode[0].'-'.$explode[1].'-'.$explode[2];
                
            }
        }
        foreach ($toeff as $key => $valvalue) {
            $explode = explode('-', $valvalue);
            if(in_array($explode[0], $alvalues) && $explode[1]== $tradeper){
                
                if(isset($_POST['effective'.$explode[0].$explode[1]])){
                    $effectcons[] = $explode[0].'-'.$explode[1].'-'.$_POST['effective'.$explode[0].$explode[1]];
                }
            }else{
                 
                 $effectcons[] = $explode[0].'-'.$explode[1].'-'.$explode[2];
            }
        }
        $sqlTrade = "UPDATE nus_supply_contract SET basegenconsumption ='".implode('|', $baseconsu)."', effectcon='".implode('|', $effectcons)."' WHERE supplierId=".$supplier."";
        $conn->query($sqlTrade);



        $sql = "SELECT nus_supply_contract.*, clientcompanydata.* FROM nus_supply_contract 
        INNER JOIN clientcompanydata ON clientcompanydata.id = nus_supply_contract.clientId 
        WHERE supplierId='".$supplier."'";

        $result = mysqli_query($conn,$sql);
        $row = mysqli_fetch_assoc($result);

    ?>

    <ul>
    <div class="sec1art1Wrapper">
            <li>
                <span>PARENT NAME</span>
                <h2><?php echo $row['parentcompany']; ?></h2>
            </li>
            <li>
                <span>CLIENT NAME</span>
                <h2><?php echo $row['clientcompany']; ?></h2>
            </li>
            <li>
                <span>CONTRACT SUMMARY REPORT</span>
                <h2><?php echo $row['contract_id']; ?></h2>
            </li>
            <br>
            <li class="supplierClass">
                <span>SUPPLIER</span>
                <h2><?php echo $row['supplyName']; ?></h2>
            </li>
                <?php
                    if($row['contractType'] == 'fixed') {
                ?>
                <li class="electricityClass">
                    <span>COMMODITY</span>
                    <h2><?php echo $row['commodityName'];?> <span class="spaneleCom" > <?php echo $row['contractType'];?></span></h2>
                </li>
                <?php
                } else {
                ?>
                <li class="gasClass">
                    <span>COMMODITY</span>
                    <h2><?php echo $row['commodityName'];?> <span class="spangasCom"> <?php echo $row['contractType'];?></span></h2>
                </li>
                <?php
                }
                ?>
            </li>
            <li class="reportPeriod">
                <span>REPORT PERIOD</span>
                <h2><?php echo $_POST['yearstype'][0]; ?></h2>
            </li>
            <li class="countryFlag">
                <span>COUNTRY</span>
                <h2><?php echo $row['countryName']; ?></h2>
            </li>
            <li>
                <span>CONTRACT CONSUMPTION (MWH)</span>
                <h2><?php echo $row['totalAnualConsumption']; ?></h2>
            </li>
            <li>
                <span>CURRENCY</span>
                <h2><?php echo $row['contractpricetype']; ?></h2>
            </li>
            </ul>
    <?php
                $consumption = $row['consumptionmonth'];
                if($row['contractType'] == 'fixed') {
                    $hedgedconsumption = $row['consumptionmonth'];
                    $price = $row['commodityPrice'];
                } else {
                    $hedgedconsumption = $row['hedgeconsumption'];
                    $price = 0;
                }
                $comm = array(explode("|",$consumption));
                $comm2 = array(explode("|",$hedgedconsumption));

                $arcount = count($comm);
                $maxcount = count($comm[0]);
                
                $arcount2 = count($comm2);
                $maxcount2 = count($comm2[0]);
                
                $consumptionpercentage = array (
                "year"=>array (),
                "month"=>array (),
                "consumption"=>array (),
                "price"=>array ()
                );
                $hedgedconsumptionpercentage = array(
                  "year"=>array(),
                  "month"=>array(),
                  "consumption"=>array(),
                  "price"=>array());
                
                function myFunc($r) {
                    $res='';
                    $comm = explode(",",$r);
                    $maxcount = count($comm);
                    for($i=0; $i<$maxcount; $i++) {
                        $res = $res.$comm[$i];
                    }
                    return $res;
                }

                // echo $maxcount;

                for($i=0; $i<$maxcount; $i++) {
                  $conn1 = array(explode("-",$comm[0][$i]));
                  if($_POST['yearstype'][0] == $conn1[0][1]) {
                    array_push($consumptionpercentage['year'],$conn1[0][1]);
                    array_push($consumptionpercentage['month'], $conn1[0][0]);
                    array_push($consumptionpercentage['consumption'], myFunc($conn1[0][2]));
                    array_push($consumptionpercentage['price'], $price);
                  } else {
                    continue;
                  }
                }
                
                for($i=0; $i<$maxcount2; $i++) {
                  $conn2 = array(explode("-",$comm2[0][$i]));
                  if($_POST['yearstype'][0] == $conn2[0][1]) {
                    array_push($hedgedconsumptionpercentage['year'],$conn2[0][1]);
                    array_push($hedgedconsumptionpercentage['month'], $conn2[0][0]);
                    array_push($hedgedconsumptionpercentage['consumption'], myFunc($conn2[0][2]));
                    array_push($hedgedconsumptionpercentage['price'], $price);
                  } else {
                    continue;
                  }
                }

                $maxcountOpen = count($consumptionpercentage['consumption']);
                // echo $maxcountOpen;
                
                $openconsumption = array(
                  "openconsumpt"=>array());
                  
                for($i=0; $i<$maxcountOpen; $i++) {
                  $sub = $consumptionpercentage["consumption"][$i]-$hedgedconsumptionpercentage["consumption"][$i];
                  array_push($openconsumption["openconsumpt"],$sub);
                }
                
                $percenthedged = array(
                  "hedgedperc"=>array());
                  
                for($i=0; $i<$maxcountOpen; $i++) {
                  $calculate = $hedgedconsumptionpercentage["consumption"][$i]/$consumptionpercentage["consumption"][$i] * 100.00;
                  array_push($percenthedged['hedgedperc'],$calculate);
                }
                
                $percentopen = array(
                  "openpercent"=>array());
                  
                for($i=0; $i<$maxcountOpen; $i++) {
                  $calculate =(float) 100 - $percenthedged['hedgedperc'][$i];
                  array_push($percentopen['openpercent'],$calculate);
                }
                // echo $row['contractType'];
                // $_SESSION['contract'] = $row['contractType'];

                //print_r($consumptionpercentage);               
                
            ?>
            
    <?php
        if($row['contractType'] == 'indexed') {
            $contType = $row['contract_id'];
            $sql1 = "SELECT * FROM enter_trade WHERE supplycontractid='$contType';";
            $result1 = mysqli_query($conn,$sql1);
            $row1 = mysqli_fetch_assoc($result1);
            //print_r($row1);

            $gen_baseprice = $row['basegenconsumption'];
                $comm3 = array(explode("|",$gen_baseprice));

                $maxcount3 = count($comm3[0]);

                $baseprice = array(
                    "month"=>array(),
                    "year"=>array(),
                    "price"=>array());
                
                    for($i=0; $i<$maxcount3; $i++) {
                        $conn3 = array(explode("-",$comm3[0][$i]));
                        if($row['yearstype'] == $conn3[0][1]){
                            array_push($baseprice['year'],$conn3[0][1]);
                            array_push($baseprice['month'], $conn3[0][0]);
                            array_push($baseprice['price'], $conn3[0][2]);
                        } else {
                            continue;

                        }
                      }

                   
                $gen_effecprice = $row['effectcon'];
                $comm4 = array(explode("|",$gen_effecprice));

                $maxcount4 = count($comm4[0]);
                echo "<h1>.$maxcount4.</h1>";

                $effecprice = array(
                    "month"=>array(),
                    "year"=>array(),
                    "price"=>array());
                
                    for($i=0; $i<$maxcount4; $i++) {
                        $conn4 = array(explode("-",$comm4[0][$i]));
                        if($row['yearstype']==$conn4[0][1]) {
                            array_push($effecprice['year'],$conn4[0][1]);
                            array_push($effecprice['month'], $conn4[0][0]);
                            array_push($effecprice['price'], $conn4[0][2]);
                        }
                        else {
                            continue;
                        }
                }
            

            $wapbaseload_price = array(
                "wapbasePrice"=>array()
            );

            $waphedged_price = array(
                "waphedgedPrice"=>array()
            );

            for($i=0; $i<$maxcount4; $i++) {
                array_push($wapbaseload_price['wapbasePrice'],$row1['baseload']);
            }

            for($i=0; $i<$maxcount4; $i++) {
                array_push($waphedged_price['waphedgedPrice'],$row1['effectiveprice']);
            }

            
            $tradeconsumption = array(
                'consumption' =>array(),
                'baseprice' =>array(),
                'effecprice'=>array()
                );
              
                $newconsumption = array(
                'consumption' =>array(),
                'baseprice' =>array(),
                'effecprice'=>array()
                );
          
                $finalconsumption = array(
                  'consumption' =>array(),
                  'baseprice' =>array(),
                  'effecprice'=>array()
                  );

                $sql1 = "SELECT * FROM enter_trade WHERE supplycontractid='$contType';";
                $result1 = mysqli_query($conn,$sql1);
                //$row1 = mysqli_fetch_assoc($result1);

                  while($row1 = mysqli_fetch_assoc($result1)) {

                    $cons = $row1['tradevolume'];
                    $consvol = explode('.',$cons);
                    // echo $consvol[0];
                    $baseprice_trade = $row1['baseload'];
                    $effecprice_trade = $row1['effectiveprice'];

                    // echo $baseprice_trade;
            
                    $tradeType = $row1['trade'];
                    //echo $tradeType;
            
                    if($tradeType == 'Calendar Yearly') {
                        $nwcons = $consvol[0]/12;
                        //echo $vol;
                        for($i=0; $i<12; $i++) {
                            array_push($tradeconsumption['consumption'],$nwcons);
                            array_push($tradeconsumption['baseprice'],$baseprice_trade);
                            array_push($tradeconsumption['effecprice'],$effecprice_trade);
                            // echo "i friedn";
                        }
                
                        echo "<pre>";
                        // print_r($consumption);
                      
                        if($newconsumption['consumption'] == NULL) {
                            for($i=0; $i<12; $i++) {
                                array_push($newconsumption['consumption'],0);
                                array_push($newconsumption['baseprice'],$baseprice_trade);
                                array_push($newconsumption['effecprice'],$effecprice_trade);
                            }
                        }
            
                        // echo $baseprice;
                
                        for($i=0; $i<12; $i++) {
                
                                $newcons = $tradeconsumption['consumption'][$i] + $newconsumption['consumption'][$i];
                                $newbase_trade = number_format((($tradeconsumption['consumption'][$i] * $tradeconsumption['baseprice'][$i]) + ($newconsumption['consumption'][$i] * $newconsumption['baseprice'][$i]))/($newcons),2);
                                $neweffec_trade = number_format((($tradeconsumption['consumption'][$i] * $tradeconsumption['effecprice'][$i]) + ($newconsumption['consumption'][$i] * $newconsumption['effecprice'][$i]))/($newcons),2);
                
                            array_push($finalconsumption['consumption'],$newcons);
                            array_push($finalconsumption['baseprice'],$newbase_trade);
                            array_push($finalconsumption['effecprice'],$neweffec_trade);
                          }
                          $newconsumption = array_replace($newconsumption,$finalconsumption);
                          for($op=0; $op<12; $op++) {
                            array_pop($tradeconsumption['consumption']);
                            array_pop($tradeconsumption['baseprice']);
                            array_pop($tradeconsumption['effecprice']);
                
                            array_pop($finalconsumption['consumption']);
                            array_pop($finalconsumption['baseprice']);
                            array_pop($finalconsumption['effecprice']);
                          }
                        }
                        //print_r($newconsumption);
                    }

                    // print_r($newconsumption['baseprice']);
            
           
    ?>
    <!-- <h1>Hi Indexed</h1> -->
    <div id = "container" style = "width: 900px; height: 400px; margin: 0 auto"></div>
    <table cellspacing="9">
        <thead>
            <th></th>
            <?php
                $countMonth = count($consumptionpercentage['month']);
                for($i=0; $i<$countMonth; $i++) {
                    echo "<th>";
                    echo $consumptionpercentage['month'][$i];
                    echo "</th>";
                }
            ?>
            <th>Total</th>
        </thead>
        <tbody>
            <tr class="hrlines">
                <td>Est. Consumption (MWh)</td>
                <?php
                    $countMonth = count($consumptionpercentage['month']);
                    for($i=0; $i<$countMonth; $i++) {
                        echo "<td>";
                        $consumption = $consumptionpercentage['consumption'][$i];
                        $regex = "/\B(?=(\d{3})+(?!\d))/i";
                        echo $usdformat = preg_replace($regex, ",", $consumption);
                        echo "</td>";
                    }
                    echo "<td>";
                    echo number_format($consumptionpercentage['consumption'][0]*12);
                    echo "</td>";
                ?>
            </tr>
            <tr>
            <td>Hedged Consumption (MWh)</td>
                <?php
                    $countCons = count($hedgedconsumptionpercentage['consumption']);
                    for($i=0; $i<$countCons; $i++) {
                        echo "<td>";
                        $consumption = $hedgedconsumptionpercentage['consumption'][$i];
                        $regex = "/\B(?=(\d{3})+(?!\d))/i";
                        echo $usdformat = preg_replace($regex, ",", $consumption);
                        echo "</td>";
                    }
                ?>
                <?php
                    $countCons = count($hedgedconsumptionpercentage['consumption']);
                    $add = 0;
                    for($i=0; $i<$countCons; $i++) {
                        $add += $hedgedconsumptionpercentage['consumption'][$i];
                    }
                    echo "<td>";
                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                    echo $usdformat = preg_replace($regex, ",", $add);
                    echo "</td>";
                ?>
            </tr>
            <tr>
            <td>Open Consumption (MWh)</td>
                <?php
                    $countCons = count($openconsumption['openconsumpt']);
                    for($i=0; $i<$countCons; $i++) {
                        echo "<td>";
                        $regex = "/\B(?=(\d{3})+(?!\d))/i";
                        $cons = $openconsumption['openconsumpt'][$i];
                        echo $usdformat = preg_replace($regex, ",", $cons);
                        echo "</td>";
                    }
                ?>
                <?php
                    $countCons = count($openconsumption['openconsumpt']);
                    $add = 0;
                    for($i=0; $i<$countCons; $i++) {
                        $add += $openconsumption['openconsumpt'][$i];
                    }
                    echo "<td>";
                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                    echo $usdformat = preg_replace($regex, ",", $add);
                    echo "</td>";
                ?>
            </tr>
            <tr>
            <td>% Hedged</td>
                <?php
                    $countCons = count($percenthedged['hedgedperc']);
                    for($i=0; $i<$countCons; $i++) {
                        echo "<td>";
                        echo number_format($percenthedged['hedgedperc'][$i],2);
                        echo "</td>";
                    }
                ?>
                
                <?php
                    $countCons = count($percenthedged['hedgedperc']);
                    $total = 0;
                    for($i=0; $i<$countCons; $i++) {
                        $total += $percenthedged['hedgedperc'][$i];                        
                    }
                        echo "<td>";
                        echo number_format($total/12,2);
                        echo "</td>";
                ?>
            </tr>
            <tr>
                <td>% Open</td>
                <?php
                    $countCons = count($percentopen['openpercent']);
                    for($i=0; $i<$countCons; $i++) {
                        echo "<td>";
                        echo number_format($percentopen['openpercent'][$i],2);
                        echo "</td>";
                    }
                ?>
                <?php
                    $countCons = count($percentopen['openpercent']);
                    $total = 0;
                    for($i=0; $i<$countCons; $i++) {
                        $total += $percentopen['openpercent'][$i];                        
                    }
                        echo "<td>";
                        echo number_format($total/12,2);
                        echo "</td>";
                ?>
            </tr>
            <tr>
                <td class='hrline'>WAP Baseload Hedged Price (per MWh)</td>
                <?php
                    $countBase = count($newconsumption['baseprice']);
                    $total = 0;
                    for($i=0; $i<$countBase; $i++) {
                        $total += $newconsumption['baseprice'][$i];
                        echo "<td class='hrline'>";
                        echo $newconsumption['baseprice'][$i];
                        echo "</td>";
                    }
                    echo "<td class='hrline'>";
                    echo number_format($total/12,2);
                    echo "</td>";
                ?>
            </tr>
            <tr>
                <td>WAP Effective Hedged Price (per MWh)</td>
                <?php
                    $countBase = count($newconsumption['effecprice']);
                    $total = 0;
                    for($i=0; $i<$countBase; $i++) {
                        $total += $newconsumption['effecprice'][$i];
                        echo "<td>";
                        echo $newconsumption['effecprice'][$i];
                        echo "</td>";
                    }
                    echo "<td>";
                    echo number_format($total/12,2);
                    echo "</td>";
                ?>
            </tr>
            <tr>
                <td>Unhedged Baseload Price (per MWh)</td>
                <?php
                    $countBaseprice = count($baseprice['price']);
                    // echo "<h1>$countBaseprice</h1>";
                    $total = 0;
                    for($i=0; $i<$countBaseprice; $i++) {
                        echo "<td>";
                        echo number_format($baseprice['price'][$i],2);
                        echo "</td>";
                        $total += $baseprice['price'][$i];
                    }
                    echo "<td>";
                    echo number_format($total/12,2);
                    echo "</td>";
                ?>
            </tr>
            <tr>
                <td>Unhedged Effective Price (per MWh)</td>
                <?php
                    $countEffecprice = count($effecprice['price']);
                    $total = 0;
                    for($i=0; $i<$countEffecprice; $i++) {
                        echo "<td>";
                        echo number_format($effecprice['price'][$i],2);
                        echo "</td>";
                        $total += $effecprice['price'][$i];
                    }
                    echo "<td>";
                    echo number_format($total/12,2);
                    echo "</td>";
                ?>
            </tr>
            <tr>
                <td class='hrlines'>Port Effective Price (Hedged + Unhedged)</td>
                <?php

                    $porteffcPrice = array(
                        "price"=>array()
                    );

                    $countPortEffecPrice = count($baseprice['price']);

                    $total = 0;

                    for($i=0; $i<$countPortEffecPrice; $i++) {
                        echo "<td class='hrlines'>";
                        $portefPrice = number_format(((($newconsumption['effecprice'][$i]*$hedgedconsumptionpercentage['consumption'][$i])+($effecprice['price'][$i]*$openconsumption['openconsumpt'][$i]))/$consumptionpercentage['consumption'][$i]),2);
                        array_push($porteffcPrice['price'],$portefPrice);
                        echo $portefPrice;
                        echo "</td>";
                        $total += $portefPrice;
                    }
                    echo "<td class='hrlines'>";
                    echo number_format(($total/12),2);
                    echo "</td>";
                ?>
            </tr>
            <tr id="tableDataColor">
                <td>Hedged Effective Commodity Cost</td>
                <?php

                    $hedgedeffcPrice = array(
                        "price"=>array()
                    );

                    $counthedgedEffecPrice = count($baseprice['price']);

                    $total = 0;

                    for($i=0; $i<$counthedgedEffecPrice; $i++) {
                        echo "<td>";
                        //$portefPrice = number_format(((($waphedged_price['waphedgedPrice'][$i]*$hedgedconsumptionpercentage['consumption'][$i])+($effecprice['price'][$i]*$openconsumption['openconsumpt'][$i]))/1000),2);
                        $hedgedPrice = ($newconsumption['effecprice'][$i]*$hedgedconsumptionpercentage['consumption'][$i]);
                        array_push($hedgedeffcPrice['price'],$hedgedPrice);
                        $regex = "/\B(?=(\d{3})+(?!\d))/i";
                        echo $usdformat = preg_replace($regex, ",", $hedgedPrice);
                        //echo $hedgedPrice;
                        $total += $hedgedPrice;
                        echo "</td>";
                    }
                    echo "<td>";
                    $res = ($total);
                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                    echo $usdformat = preg_replace($regex, ",", $res);
                    echo "</td>";
                    
                ?>
            </tr>
            <tr id="tableDataColor">
                <td>Unhedged Effective Cost (VaR)</td>
                <?php
                    $unhedgedEfecCost = array(
                        "price"=>array()
                    );

                    $counthedgedEffecPrice = count($baseprice['price']);

                    $total = 0;

                    for($i=0; $i<$counthedgedEffecPrice; $i++) {
                        echo "<td>";
                        //$portefPrice = number_format(((($waphedged_price['waphedgedPrice'][$i]*$hedgedconsumptionpercentage['consumption'][$i])+($effecprice['price'][$i]*$openconsumption['openconsumpt'][$i]))/1000),2);
                        $unhedgedPrice = ($effecprice['price'][$i]*$openconsumption['openconsumpt'][$i]);
                        array_push($unhedgedEfecCost['price'],$unhedgedPrice);
                        $regex = "/\B(?=(\d{3})+(?!\d))/i";
                        echo $usdformat = preg_replace($regex, ",", $unhedgedPrice);
                        //echo $hedgedPrice;
                        $total += $unhedgedPrice;
                        echo "</td>";
                    }
                    echo "<td>";
                    $res = ($total);
                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                    echo $usdformat = preg_replace($regex, ",", $res);
                    echo "</td>";
                ?>
            </tr>
            <tr class="hrlines" id="tableDataColor">
                <td>Est. Portfolio Commodity Cost</td>
                <?php
                   
                    $counthedgedEffecPrice = count($baseprice['price']);

                    $total = 0;

                    for($i=0; $i<$counthedgedEffecPrice; $i++) {
                        echo "<td>";
                        $estPortCost = ($consumptionpercentage['consumption'][$i]*$porteffcPrice['price'][$i]);
                        $regex = "/\B(?=(\d{3})+(?!\d))/i";
                        echo $usdformat = preg_replace($regex, ",", $estPortCost);
                        $total += $estPortCost;
                        echo "</td>";
                    }
                    echo "<td>";
                    $res = ($total);
                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                    echo $usdformat = preg_replace($regex, ",", $res);
                    echo "</td>";
                ?>
            </tr>
        </tbody>
    </table>
    <?php
        } else {
    ?>
    <!-- <h1>Hi Fixed</h1> -->
    <div id="top_x_div" style="width: 900px; height: 500px;"></div>
    <table>
        <thead>
            <th></th>
            <?php
                $countMonth = count($consumptionpercentage['month']);
                for($i=0; $i<$countMonth; $i++) {
                    echo "<th>";
                    echo $consumptionpercentage['month'][$i];
                    echo "</th>";
                }
            ?>
            <th>Total</th>
        </thead>
        <tbody>
            <tr class="hrline">
                <td>Est Consumption (MWh)</td>
                <?php
                    $countMonth = count($consumptionpercentage['month']);
                    for($i=0; $i<$countMonth; $i++) {
                        echo "<td>";
                        $consumption = $consumptionpercentage['consumption'][$i];
                        $regex = "/\B(?=(\d{3})+(?!\d))/i";
                        echo $usdformat = preg_replace($regex, ",", $consumption);
                        echo "</td>";
                    }
                ?>
                <td>
                    <?php 
                        echo number_format($consumptionpercentage['consumption'][0]*12);
                    ?>
                </td>
            </tr>
            <tr>
            <td>Hedged Consumption (MWh)</td>
                <?php
                    $countCons = count($hedgedconsumptionpercentage['consumption']);
                    for($i=0; $i<$countCons; $i++) {
                        echo "<td>";
                        $consumption = $hedgedconsumptionpercentage['consumption'][$i];
                        $regex = "/\B(?=(\d{3})+(?!\d))/i";
                        echo $usdformat = preg_replace($regex, ",", $consumption);
                        echo "</td>";
                    }
                ?>
                <?php
                    $countCons = count($hedgedconsumptionpercentage['consumption']);
                    $add = 0;
                    for($i=0; $i<$countCons; $i++) {
                        $add += $hedgedconsumptionpercentage['consumption'][$i];
                    }
                    echo "<td>";
                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                    $usdformat = preg_replace($regex, ",", $add);
                    echo $usdformat;
                    echo "</td>";
                ?>
            </tr>
            <tr>
            <td>Open Consumption (MWh)</td>
                <?php
                    $countCons = count($openconsumption['openconsumpt']);
                    for($i=0; $i<$countCons; $i++) {
                        echo "<td>";
                        $regex = "/\B(?=(\d{3})+(?!\d))/i";
                        $cons = $openconsumption['openconsumpt'][$i];
                        echo $usdformat = preg_replace($regex, ",", $cons);
                        echo "</td>";
                    }
                ?>
                <?php
                    $countCons = count($openconsumption['openconsumpt']);
                    $add = 0;
                    for($i=0; $i<$countCons; $i++) {
                        $add += $openconsumption['openconsumpt'][$i];
                    }
                    echo "<td>";
                    $regex = "/\B(?=(\d{3})+(?!\d))/i";
                    echo $usdformat = preg_replace($regex, ",", $add);
                    echo "</td>";
                ?>
            </tr>
            <tr>
            <td>% Hedged</td>
                <?php
                    $countCons = count($percenthedged['hedgedperc']);
                    for($i=0; $i<$countCons; $i++) {
                        echo "<td>";
                        echo number_format($percenthedged['hedgedperc'][$i],2);
                        echo "</td>";
                    }
                ?>
                
                <?php
                    $countCons = count($percenthedged['hedgedperc']);
                    $total = 0;
                    for($i=0; $i<$countCons; $i++) {
                        $total += $percenthedged['hedgedperc'][$i];                        
                    }
                        echo "<td>";
                        echo number_format($total/12,2);
                        echo "</td>";
                ?>
            </tr>
            <tr>
            <td>% Open</td>
                <?php
                    $countCons = count($percentopen['openpercent']);
                    for($i=0; $i<$countCons; $i++) {
                        echo "<td>";
                        echo number_format($percentopen['openpercent'][$i],2);
                        echo "</td>";
                    }
                ?>
                <?php
                    $countCons = count($percentopen['openpercent']);
                    $total = 0;
                    for($i=0; $i<$countCons; $i++) {
                        $total += $percentopen['openpercent'][$i];                        
                    }
                        echo "<td>";
                        echo number_format($total/12,2);
                        echo "</td>";
                ?>
            </tr>
            <tr class="hrline">
            <td>Fixed Commodity Price<br>(per MWh)</td>
                <?php
                    $countCons = count($consumptionpercentage['price']);
                    $total = 0;
                    for($i=0; $i<$countCons; $i++) {
                        echo "<td>";
                        $total += $consumptionpercentage['price'][$i];
                        echo $consumptionpercentage['price'][$i];
                        echo "</td>";
                    }
                ?>
                <td>
                    <?php
                        echo number_format($total/12,2);
                    ?>
                </td>
            </tr>
            <tr>
            <td>Port Effective Price<br>(Hedged + Unhedged)</td>
                <?php
                    $countCons = count($consumptionpercentage['price']);
                    $total = 0;
                    for($i=0; $i<$countCons; $i++) {
                        echo "<td>";
                        $total += $consumptionpercentage['price'][$i];
                        echo $consumptionpercentage['price'][$i];
                        echo "</td>";
                    }
                ?>
                <td>
                    <?php
                        echo number_format($total/12,2);
                    ?>
                </td>
            </tr>
            <tr class="line" id ="tableDataColor">
            <td>Est. Portfolio<br>Commodity Cost</td>
                <?php
                    $total = 0;
                    $countCons = count($consumptionpercentage['price']);
                    for($i=0; $i<$countCons; $i++) {
                        echo "<td>";
                        $add = ($consumptionpercentage['price'][$i]*$consumptionpercentage['consumption'][$i]);
                        $total += $add;
                        $regex = "/\B(?=(\d{3})+(?!\d))/i";
                        echo $usdformat = preg_replace($regex, ",", $add);
                        echo "</td>";
                    }
                ?>
                <td>
                    <?php
                        // $totalConsumption = myFunc(number_format(($consumptionpercentage['consumption'][0]*12)));
                        // $totalAmount = $consumptionpercentage['price'][0]*12;
                        // $finalAmount = $totalAmount * $totalConsumption;
                        $regex = "/\B(?=(\d{3})+(?!\d))/i";
                        $usdformat = preg_replace($regex, ",", $total);
                        echo $usdformat;
                        //echo $finalAmount;
                    ?>
                </td>
            </tr>
            
        </tbody>
    </table>
    <?php
        }
    ?>
    
</body>
<script>
        google.charts.load('current', {'packages':['bar']});
        google.charts.setOnLoadCallback(drawStuff);

      function drawStuff() {
        var data = new google.visualization.arrayToDataTable([
          ['Month', 'MWh'],
          ["<?php echo $consumptionpercentage['month'][0]; ?>", "<?php echo $consumptionpercentage['consumption'][0]?>"],
          ["<?php echo $consumptionpercentage['month'][1]; ?>", "<?php echo $consumptionpercentage['consumption'][1]?>"],
          ["<?php echo $consumptionpercentage['month'][2]; ?>", "<?php echo $consumptionpercentage['consumption'][2]?>"],
          ["<?php echo $consumptionpercentage['month'][3]; ?>", "<?php echo $consumptionpercentage['consumption'][3]?>"],
          ["<?php echo $consumptionpercentage['month'][4]; ?>", "<?php echo $consumptionpercentage['consumption'][4]?>"],
          ["<?php echo $consumptionpercentage['month'][5]; ?>", "<?php echo $consumptionpercentage['consumption'][5]?>"],
          ["<?php echo $consumptionpercentage['month'][6]; ?>", "<?php echo $consumptionpercentage['consumption'][6]?>"],
          ["<?php echo $consumptionpercentage['month'][7]; ?>", "<?php echo $consumptionpercentage['consumption'][7]?>"],
          ["<?php echo $consumptionpercentage['month'][8]; ?>", "<?php echo $consumptionpercentage['consumption'][8]?>"],
          ["<?php echo $consumptionpercentage['month'][9]; ?>", "<?php echo $consumptionpercentage['consumption'][9]?>"],
          ["<?php echo $consumptionpercentage['month'][10]; ?>", "<?php echo $consumptionpercentage['consumption'][10]?>"],
          ["<?php echo $consumptionpercentage['month'][11]; ?>", "<?php echo $consumptionpercentage['consumption'][11]?>"]
        ]);

        var options = {
          title: 'Hedged Position Chart',
          width: 900,
          legend: { position: 'none' },
          chart: { title: 'Hedged Consumption Chart',
                   subtitle: 'consumption in MWh' },
          bars: 'vertical', // Required for Material Bar Charts.
          axes: {
            x: {
              0: { side: 'bottom', label: 'Months'} // Top x-axis.
            },
            y: {
              0: { side: 'top', label: 'Total Consumption (MWh)'}
            }
            
          },
          bar: { groupWidth: "90%" }
        };

        var chart = new google.charts.Bar(document.getElementById('top_x_div'));
        chart.draw(data, options);
      };
</script>
<script>
    
    function drawChart() {
            // Define the chart to be drawn.
            var data = google.visualization.arrayToDataTable([
               ['Month', 'Hedged Consuption', 'Open Consumption'],
               ["<?php echo $hedgedconsumptionpercentage['month'][0]; ?>",  <?php echo $hedgedconsumptionpercentage['consumption'][0]; ?>, <?php echo $openconsumption['openconsumpt'][0]; ?>],
               ["<?php echo $hedgedconsumptionpercentage['month'][1]; ?>",  <?php echo $hedgedconsumptionpercentage['consumption'][1]; ?>, <?php echo $openconsumption['openconsumpt'][1]; ?>],
               ["<?php echo $hedgedconsumptionpercentage['month'][2]; ?>",  <?php echo $hedgedconsumptionpercentage['consumption'][2]; ?>, <?php echo $openconsumption['openconsumpt'][2]; ?>],
               ["<?php echo $hedgedconsumptionpercentage['month'][3]; ?>",  <?php echo $hedgedconsumptionpercentage['consumption'][3]; ?>, <?php echo $openconsumption['openconsumpt'][3]; ?>],
               ["<?php echo $hedgedconsumptionpercentage['month'][4]; ?>",  <?php echo $hedgedconsumptionpercentage['consumption'][4]; ?>, <?php echo $openconsumption['openconsumpt'][4]; ?>],
               ["<?php echo $hedgedconsumptionpercentage['month'][5]; ?>",  <?php echo $hedgedconsumptionpercentage['consumption'][5]; ?>, <?php echo $openconsumption['openconsumpt'][5]; ?>],
               ["<?php echo $hedgedconsumptionpercentage['month'][6]; ?>",  <?php echo $hedgedconsumptionpercentage['consumption'][6]; ?>, <?php echo $openconsumption['openconsumpt'][6]; ?>],
               ["<?php echo $hedgedconsumptionpercentage['month'][7]; ?>",  <?php echo $hedgedconsumptionpercentage['consumption'][7]; ?>, <?php echo $openconsumption['openconsumpt'][7]; ?>],
               ["<?php echo $hedgedconsumptionpercentage['month'][8]; ?>",  <?php echo $hedgedconsumptionpercentage['consumption'][8]; ?>, <?php echo $openconsumption['openconsumpt'][8]; ?>],
               ["<?php echo $hedgedconsumptionpercentage['month'][9]; ?>",  <?php echo $hedgedconsumptionpercentage['consumption'][9]; ?>, <?php echo $openconsumption['openconsumpt'][9]; ?>],
               ["<?php echo $hedgedconsumptionpercentage['month'][10]; ?>",  <?php echo $hedgedconsumptionpercentage['consumption'][10]; ?>, <?php echo $openconsumption['openconsumpt'][10]; ?>],
               ["<?php echo $hedgedconsumptionpercentage['month'][11]; ?>",  <?php echo $hedgedconsumptionpercentage['consumption'][11]; ?>, <?php echo $openconsumption['openconsumpt'][11]; ?>]
            ]);

            var options = {title: 'Hedged Consumption in MWh', isStacked:true};  

            // Instantiate and draw the chart.
            var chart = new google.visualization.ColumnChart(document.getElementById('container'));
            chart.draw(data, options);
            console.log('Intel inside');
         }
         google.charts.setOnLoadCallback(drawChart);
</script>

</html>